document.addEventListener('DOMContentLoaded', function () {
  const display = document.getElementById('display');
  const startPauseBtn = document.getElementById('startPauseBtn');
  const resetBtn = document.getElementById('resetBtn');
  const lapBtn = document.getElementById('lapBtn');
  const lapsContainer = document.getElementById('laps');

  let startTime = 0;
  let elapsedTime = 0;
  let intervalId = null;
  let isRunning = false;

  function formatTime(time) {
    const milliseconds = Math.floor((time % 1000) / 10);
    const seconds = Math.floor((time / 1000) % 60);
    const minutes = Math.floor((time / 60000) % 60);
    const hours = Math.floor(time / 3600000);
    
    return {
      hours: String(hours).padStart(2, '0'),
      minutes: String(minutes).padStart(2, '0'),
      seconds: String(seconds).padStart(2, '0'),
      milliseconds: String(milliseconds).padStart(2, '0'),
    };
  }

  function updateDisplay(time) {
    const formattedTime = formatTime(time);
    display.querySelector('.hours').textContent = formattedTime.hours;
    display.querySelector('.minutes').textContent = formattedTime.minutes;
    display.querySelector('.seconds').textContent = formattedTime.seconds;
    display.querySelector('.milliseconds').textContent = formattedTime.milliseconds;
  }

  function startPauseStopwatch() {
    if (isRunning) {
      clearInterval(intervalId);
      elapsedTime += Date.now() - startTime;
      startPauseBtn.textContent = 'Start';
      startPauseBtn.classList.remove('pause');
      startPauseBtn.classList.add('start');
      lapBtn.disabled = true;
      isRunning = false;
    } else {
      startTime = Date.now();
      intervalId = setInterval(function () {
        updateDisplay(elapsedTime + Date.now() - startTime);
      }, 10);
      startPauseBtn.textContent = 'Pause';
      startPauseBtn.classList.remove('start');
      startPauseBtn.classList.add('pause');
      resetBtn.disabled = false;
      lapBtn.disabled = false;
      isRunning = true;
    }
  }

  function resetStopwatch() {
    clearInterval(intervalId);
    startTime = 0;
    elapsedTime = 0;
    isRunning = false;
    updateDisplay(0);
    startPauseBtn.textContent = 'Start';
    startPauseBtn.classList.remove('pause');
    startPauseBtn.classList.add('start');
    resetBtn.disabled = true;
    lapBtn.disabled = true;
    lapsContainer.innerHTML = '';
  }

  function recordLap() {
    const lapTime = elapsedTime + Date.now() - startTime;
    const lapElement = document.createElement('p');
    const formattedTime = formatTime(lapTime);
    lapElement.textContent = `Lap ${lapsContainer.children.length + 1}: ${formattedTime.hours}:${formattedTime.minutes}:${formattedTime.seconds}.${formattedTime.milliseconds}`;
    lapsContainer.appendChild(lapElement);
    lapsContainer.scrollTop = lapsContainer.scrollHeight;
  }

  startPauseBtn.addEventListener('click', startPauseStopwatch);
  resetBtn.addEventListener('click', resetStopwatch);
  lapBtn.addEventListener('click', recordLap);
});
